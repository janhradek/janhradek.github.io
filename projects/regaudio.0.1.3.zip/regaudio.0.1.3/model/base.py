import sqlalchemy.ext.declarative
Base = sqlalchemy.ext.declarative.declarative_base()
