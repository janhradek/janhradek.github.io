'''
Created on Mar 8, 2012

@author: twider
'''
import sqlalchemy.ext.declarative
Base = sqlalchemy.ext.declarative.declarative_base()